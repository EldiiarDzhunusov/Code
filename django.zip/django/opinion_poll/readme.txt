This project is an Opinion pull, you create a pull in admin part and any user may vote inside of the question for options.

Django==2.2.5 was used while creating it and the source was this youtube video
https://www.youtube.com/watch?v=e1IyzVyrLSU


pip3 install Django==2.2.5
