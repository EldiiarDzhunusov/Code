This project is a task manager, you add task and description and then you can see them sorted by their id.
Django==3.0.7 was used while creating it and the source was this youtube video
https://www.youtube.com/watch?v=6K83dgjkQNw


pip3 install Django==3.0.7
